//
//  AraratOrNot.h
//  AraratOrNot
//
//  Created by Sevak Soghoyan on 8/3/20.
//  Copyright © 2020 Sevak Soghoyan. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AraratOrNot.
FOUNDATION_EXPORT double AraratOrNotVersionNumber;

//! Project version string for AraratOrNot.
FOUNDATION_EXPORT const unsigned char AraratOrNotVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AraratOrNot/PublicHeader.h>


